
public class Nodo {
    int info;
    Nodo sig;
    Nodo ant;


    public Nodo(int info){
        this.info=info;
        this.sig=null;
        this.ant=null;
    }

}
